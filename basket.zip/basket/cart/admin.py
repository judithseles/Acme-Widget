from django.contrib import admin
from cart.models import ProductCatalogue
from cart.apps import CartConfig

class ProductCatalogueAdmin(admin.ModelAdmin):
    """
    class to register ProductCatalogue model
    """
    model = ProductCatalogue
    list_display = ["product", "code", "price"]

admin.site.register(ProductCatalogue, ProductCatalogueAdmin)

