import json

def load_json_file(filename, path):
    """
    Utility function to read json data
    """
    try:
        with open(path + filename, "r") as read_file:
            return json.load(read_file)
    except Exception as ex:
        raise Exception(
            msg="The product catalogue JSON is invalid", ex=ex)