FILE_NAME = "product_catalogue.json"
FILE_DIR = "cart/"