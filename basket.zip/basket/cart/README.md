ACME WIDGET CO : Calculate total cost of the orders considering the special offers and delivery rates.

Pre-requisites:
Create a db named 'acme_widget' in postgres

Create virtual environment : virtualenv venv
Install requirements : pip install -r requirements.txt
Runserver : python manage.py runserver--noreload
Enter the product codes : Ex:- R01,B01,G01
Total is printed in the utput console

Run tests : python manage.py test cart.tests