import os

# prevents reload of the application
if os.environ.get('RUN_MAIN', None) != 'true':
    default_app_config = 'cart.apps.CartConfig'