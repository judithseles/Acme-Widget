from django.db import models

# Create your models here.
class ProductCatalogue(models.Model):
    product = models.TextField(blank=False)
    code = models.TextField(blank=False)
    price =models.TextField(blank=False)

    def __str__(self):
        return self.price[1:]