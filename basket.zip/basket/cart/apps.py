from django.apps import AppConfig
from cart.utils import load_json_file
from cart.constants import FILE_NAME, FILE_DIR

import math
import sys

class CartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cart'

    def ready(self):
        if not 'test' in sys.argv and not 'migrate' in sys.argv and not 'makemigrations' in sys.argv:
            file_name = FILE_NAME
            file_dir = FILE_DIR
            catalogue = load_json_file(file_name, file_dir)
            self.__initialize_db(catalogue)

    # To move it to another folder which has only db operations
    def __initialize_db(self, catalogue):
        """
        Initialize db with catalogue values
        """
        from cart.models import ProductCatalogue
        res = ProductCatalogue.objects.all().count()
        # transactions can be used 
        if not res:
            for values in catalogue:
                for key, val in values.items():
                    ProductCatalogue.objects.create(
                        product= key,
                        code=val[0],
                        price=val[1])
        add_products = input("Add product code in a list : ")
        # validation on input required (like checking valid code is entered)
        if len(add_products):
            self.add(add_products)

    def add(self, add_products):
        # input is given in proper format
        # assuming input is given in a proper format
        from cart.models import ProductCatalogue
        order_list = []
        flag = 0
        try:
            # To think of another way if special offers is exteded to other products
            # In that case create one more model for special offers
            for arg in add_products.split(","):
                if arg == "R01" and flag == 0:
                    cost = ProductCatalogue.objects.get(code=arg)
                    flag = 1
                elif arg == "R01" and flag == 1:
                    cost = ProductCatalogue.objects.get(code=arg)
                    cost =float(str(cost)) / 2
                    flag = 0
                else:
                    cost = ProductCatalogue.objects.get(code=arg)
                order_list.append(float(str(cost)))
        except Exception as e:
            # Handle with custom exceptions
            raise e
        return self.total(order_list)

    def total(self,order_list):
        total = sum(order_list)
        summary = self.calculate_delivery(total)
        print("Total Cost of the Basket : $" + str(summary))
        return summary
    
    def calculate_delivery(self,total):
        #To remove hard coded values and get delivery charges from db
        #Create a model capturing delivery charges
        if total <= 50:
            total = total + 4.95
        elif 50 <= total <= 90:
            total = total+ 2.95
        total = math.floor(total* 10**2) / 10.0**2
        return total