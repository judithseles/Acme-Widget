from django.test import TestCase
import cart
from cart.apps import CartConfig
from cart.models import ProductCatalogue

class AddProducts(TestCase):
    
    def setUp(self):
        ProductCatalogue.objects.create(product="Red Widget", code="R01", price="$32.95")
        ProductCatalogue.objects.create(product="Green Widget ", code="G01", price="$24.95")
        ProductCatalogue.objects.create(product="Blue Widget", code="B01", price="$7.95")
    
    def test_db(self):
        res = ProductCatalogue.objects.all().count
        self.assertTrue(res)

    def test_add_product(self):
        order_total = CartConfig(app_name="cart",app_module=cart.tests).add('B01,B01,R01,R01,R01')
        self.assertEquals(order_total, 98.27)

    def test_total(self):
        total = CartConfig(app_name="cart",app_module=cart.tests).total([24.95,32.95,7.95])
        self.assertEquals(total, 68.8)

    def test_delivery(self):
        total = 68
        deliverycharge = CartConfig(app_name="cart",app_module=cart.tests).calculate_delivery(total)
        self.assertEquals(deliverycharge, total+2.95)
